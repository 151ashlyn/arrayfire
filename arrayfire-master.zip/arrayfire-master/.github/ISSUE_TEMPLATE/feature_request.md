---
name: Feature Request
about: Suggest a new idea for ArrayFire
title: ''
labels: 'feature'
assignees: ''

---

<!-- One or two sentences describing the feature. -->

Description
===========
<!--
* Additional information about the feature you would like to add
* What problem are you trying to solve?
* (Optional) API of new function
* (Optional) Algorithms that could be used to implement this feature
* (Optional)Are there other libraries that implement this feature?
-->
